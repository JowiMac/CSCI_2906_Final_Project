/* John Macdonald February 22, 2023
 * 
 * This program "Tourney Command" aims to automate
 * current manual processes in game stores that host
 * Magic: the Gathering Commander play style
 * 
 * used 4 enter spaces between blocks of code
 * on the 5th enter code continues
 * 3 enter spaces between lambda expressions
 * 
 * It looks nice visually after the overhaul but may
 * still be subject to change. At least it will be
 * easier to change it
 * 
 * Areas that need work
 *  -Tournament tab			Not Started
 *  -Array organization		Complete
 *  -Method creation		Almost Complete
 *  -ReRandomize button		Almost Complete
 *  was working on the Start button for timing
 * */

package tourneyCommand;

import javafx.application.*;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.*;

import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Timer;

import javafx.scene.chart.*;
import javafx.scene.chart.XYChart.Series;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.text.*;
import javafx.event.*;
import javafx.scene.shape.*;
import javafx.collections.*;

public class Tourney_Command extends Application {
	public static void main(String[] args) {
		
		launch(args);
		
	}//Method main end
	
	
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		
	//TabPane and tabs
		TabPane tabPane = new TabPane();
		
		Tab setup = new Tab("Setup");
				setup.setClosable(false);

		Tab rounds = new Tab("Rounds");
				rounds.setClosable(false);

		Tab enterWins = new Tab("Enter Wins");
				enterWins.setClosable(false);
		
		tabPane.getTabs().addAll(setup, rounds, enterWins);
		
		
		
		
	//Setup tab
		GridPane setupNR = new GridPane();
		setupNR.setAlignment(Pos.CENTER);
		setupNR.setVgap(20);
//		ColumnConstraints width = new ColumnConstraints();
//		width.setPercentWidth(60);
//		setupNR.getColumnConstraints().add(width);
//		setupNR.setGridLinesVisible(true);				//used for testing purposes
		
		HBox setupNames = new HBox();
		setupNames.setSpacing(10);
		setupNames.setAlignment(Pos.BASELINE_CENTER);
		
		HBox setupSysNames = new HBox();
		setupSysNames.setSpacing(12);
		setupSysNames.setAlignment(Pos.CENTER);

		HBox setupNTotal = new HBox();
		setupNTotal.setSpacing(10);
		setupNTotal.setAlignment(Pos.CENTER);
		
		HBox setupRounds = new HBox();
		setupRounds.setSpacing(10);
		setupRounds.setAlignment(Pos.CENTER);
		
		setupNR.add(setupNames, 0, 0);
		setupNR.add(setupSysNames, 0, 1);
		setupNR.add(setupNTotal, 0, 2);
		setupNR.add(setupRounds, 0, 3);
		
		
		
		
	//Rounds tab
		GridPane roundPane = new GridPane();
		roundPane.setPadding(new Insets(20, 20, 20, 20));
		roundPane.setAlignment(Pos.CENTER);
		roundPane.setHgap(10);
		roundPane.setVgap(10);
		
		HBox roundText = new HBox();
		roundPane.add(roundText, 0, 0);
		roundText.setSpacing(20);
		
		HBox roundButtons = new HBox();
		roundPane.add(roundButtons, 0, 2);
		roundButtons.setSpacing(110);
		
		
		
		HBox sideRound = new HBox();
		roundPane.add(sideRound, 0, 1);
		sideRound.setSpacing(10);
		
	//Enter Wins tab - yet to be completed
		GridPane winPane = new GridPane();
		winPane.setPadding(new Insets(20, 20, 20, 20));
		winPane.setAlignment(Pos.CENTER);
		winPane.setHgap(10);
		winPane.setVgap(10);
		
		
		setup.setContent(setupNR);
				
		rounds.setContent(roundPane);
		
		enterWins.setContent(winPane);
		
		Scene scene = new Scene(tabPane, 580, 310);
		
		
		
		
	
		
		
		
	//Rework entirely the array system to use object encapsulation
		//with object encapsulation I can create a new object "player"
		//and have their name and wins listed under them
		//methods can get name or wins of player
		//may be able to salvage some of it
		
		ArrayList list = new ArrayList();
		
	//to move crucial numbers between lambda expressions
		int[] btnRandoPress = {0};
		int[] totalGroupsAr = {0};
		int[] people4Ar = {0};
		int[] people3Ar = {0};
		ArrayList matrixCloneAr = new ArrayList();
		
		
		
		
	//found in Setup tab
		
	//setupNames HBox
		Label enterNames = new Label("Enter Names here: ");
		setupNames.setMargin(enterNames, new Insets(10, 0, 10, 0));
		
		TextField textField = new TextField();
		textField.setEditable(true);
		
	//setupSysNames HBox
		Label namesIn = new Label("Names in System: ");
		setupSysNames.setMargin(namesIn, new Insets(0, 0, 0, 31));
		
		TextField nameInSy = new TextField();
		nameInSy.setEditable(false);
		
	//nameTotal HBox
		Label namesEntered = new Label("Total number of names entered: ");
		setupNTotal.setMargin(enterNames, new Insets(10, 0, 0, 30));

		TextField nameTotal = new TextField();
		nameTotal.setEditable(false);
		nameTotal.setMaxWidth(60);
		
	//setupRounds HBox
		Label enterRounds = new Label("Enter Rounds here: ");
		setupRounds.setMargin(enterRounds, new Insets(6, 0, 6, 30));
		
		Spinner roundSpin = new Spinner(1, 20, 3);
		setupRounds.setMargin(roundSpin, new Insets(0, 0, 0, 0));
		roundSpin.setMaxWidth(60);
		roundSpin.setEditable(true);
		
		Button finalize = new Button("Finalize");
		setupRounds.setMargin(finalize, new Insets(0, 0, 0, 30));
		
		
		
		
		
	//found in Rounds tab
		
		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setMaxWidth(250);
		
		TextArea textWins = new TextArea();
		textWins.setEditable(false);
		textWins.setMaxWidth(250);
		
		roundText.getChildren().addAll(textArea, textWins);
		
		Label roundsText = new Label("Rounds Left:");
		sideRound.setMargin(roundsText, new Insets(6, 0, 0, 0));
		
		TextField roundsLeft = new TextField();
		roundsLeft.setEditable(false);
		roundsLeft.setMaxWidth(35);

		Button addARound = new Button("Add a Round");
		
		Label stopText = new Label("Time Left: (Seconds)");
		sideRound.setMargin(stopText, new Insets(6, 0, 0, 50));
		
		TextField timeLeft = new TextField();
		timeLeft.setEditable(true);
		timeLeft.setMaxWidth(50);
		
		Button stopWatch = new Button("Start");
		
		Button allNames = new Button("Names & Wins");
		
		Button reRandomize = new Button("Re-Randomize");
		
		Button help = new Button("Help");
		help.setPrefWidth(100);
		
		sideRound.getChildren().addAll(roundsText, roundsLeft, addARound, stopText, timeLeft, stopWatch);
		roundButtons.getChildren().addAll(reRandomize, allNames, help);
		roundButtons.relocate(0, 200);
		
//added a timer and may place it in a spinner or combo box
		Spinner time = new Spinner(1, 30, 10);
		
//		Timer timer = new Timer();
//		timer.schedule(, 0);
		
		
	//found in enter Wins tab
		Label st = new Label("1st");
		winPane.add(st, 1, 0);
		st.setTranslateX(17);
		
		Label nd = new Label("2nd");
		winPane.add(nd, 2, 0);
		nd.setTranslateX(15);
		
		Label rd = new Label("3rd");
		winPane.add(rd, 3, 0);
		rd.setTranslateX(15);
		
		Label th = new Label("4th");
		winPane.add(th, 4, 0);
		th.setTranslateX(15);
		
		
		Label group1 = new Label("Group 1 placings:");
		winPane.add(group1, 0, 1);
		
		ComboBox cBox1Place1 = new ComboBox();
		winPane.add(cBox1Place1, 1, 1);
		ComboBox cBox1Place2 = new ComboBox();
		winPane.add(cBox1Place2, 2, 1);
		ComboBox cBox1Place3 = new ComboBox();
		winPane.add(cBox1Place3, 3, 1);
		ComboBox cBox1Place4 = new ComboBox();
		winPane.add(cBox1Place4, 4, 1);
		
		
		
		Label group2 = new Label("Group 2 placings:");
		winPane.add(group2, 0, 2);
		
		ComboBox cBox2Place1 = new ComboBox();
		winPane.add(cBox2Place1, 1, 2);
		ComboBox cBox2Place2 = new ComboBox();
		winPane.add(cBox2Place2, 2, 2);
		ComboBox cBox2Place3 = new ComboBox();
		winPane.add(cBox2Place3, 3, 2);
		ComboBox cBox2Place4 = new ComboBox();
		winPane.add(cBox2Place4, 4, 2);

		
		
		Label group3 = new Label("Group 3 placings:");
		winPane.add(group3, 0, 3);

		ComboBox cBox3Place1 = new ComboBox();
		winPane.add(cBox3Place1, 1, 3);
		ComboBox cBox3Place2 = new ComboBox();
		winPane.add(cBox3Place2, 2, 3);
		ComboBox cBox3Place3 = new ComboBox();
		winPane.add(cBox3Place3, 3, 3);
		ComboBox cBox3Place4 = new ComboBox();
		winPane.add(cBox3Place4, 4, 3);

		
		
		Label group4 = new Label("Group 4 placings:");
		winPane.add(group4, 0, 4);
		
		ComboBox cBox4Place1 = new ComboBox();
		winPane.add(cBox4Place1, 1, 4);
		ComboBox cBox4Place2 = new ComboBox();
		winPane.add(cBox4Place2, 2, 4);
		ComboBox cBox4Place3 = new ComboBox();
		winPane.add(cBox4Place3, 3, 4);
		ComboBox cBox4Place4 = new ComboBox();
		winPane.add(cBox4Place4, 4, 4);
		
		Button enterPlaces = new Button("Enter Places");
		winPane.add(enterPlaces, 5, 5);


		
		
		
		
		
	//textField enter action
		textField.setOnKeyPressed(e -> {
			if(e.getCode() == KeyCode.ENTER) {
				String name = (textField.getText().trim());
				String stop = "Please pick a different name\n"
						+ "Click the show names button\n"
						+ "to continue entering names";
				if(name.isEmpty()) {
					textArea.setText(stop);
				}

				for(int i = 0; i < list.size(); i++) {
				if(name.equals((String)((Player) list.get(i)).getName()) == true) {
					textArea.setText(stop);
				}//if in for loop end
				
				}//for loop end
				
				if(textArea.getText().equals(stop) == false) {
					
				list.add(new Player());
				
				Integer count = list.size();

				((Player) list.get(list.size() - 1)).setName(name);
				
				
				
				
				
				String nameSystem = nameInSy.getText();
				nameInSy.setText(nameSystem.concat(name + ", "));
				
				textField.clear();
				nameTotal.setText(count.toString());
				textArea.setText(count.toString() + " Names entered");
				}//if end
				

				
			}//if(e.getCode() end
			
		});//textField.setOnKeyPressed(e -> { end
		
		
		
	//finalize button action
		finalize.setOnAction(e -> {
			
			roundsLeft.setText(Integer.toString((int) roundSpin.getValue()));
			
			//block from Show names button
			String Results = "";
			String names = "";
			int wins;
			int l = 1;
			
			for(int i = 0; i < list.size(); i++) {

			names = (String) ((Player) list.get(i)).getName();
			wins = (Integer) ((Player) list.get(i)).getWins();
			
			if(l % 4 == 0) {
				l = 1;
				Results = Results.concat(names + " - " + wins + "\n");
			}
			
			else {
				l++;
			Results = Results.concat(names + " - " + wins + ",  ");
			}
			
			}//for loop end
			Results = Results.concat("\n");
			
			
			try {
			((Player) list.get(0)).getName();
			}//try end
			catch (Exception k) {
				Results = "Please enter a name into the text field";
			}//catch end
			finally {
				textArea.setText(Results);
			}//finally end
			
			
			//block from Calculate groups button
			int totalGroups = 0;
			int groupsOf3 = 0;
			int groupsOf4 = 0;
			
			if(list.size() == 0 || list.size() == 1) {
				textArea.setText("Please enter at least two names");
			}//if end
			
			else if(list.size() == 2 || list.size() == 3 || list.size() == 4 || list.size() == 5) {
				textArea.setText("");
				String name = "";
				
				for(int i = 0; i < list.size(); i++) {
				name = (String) ((Player) list.get(i)).getName();
				Results = Results.concat(name + ", ");
				}
				
				textArea.setText(Results + "are in a group");

			}//else if end

			
			else if((list.size() % 4) == 1 && list.size() > 5) {
				if ((list.size() % 3) == 0 && list.size() == 9){
					//groups of 3 only
					groupsOf3 = 3;
					groupsOf4 = 0;
					totalGroups = groupsOf3;
					Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
					textArea.setText(Results);
					//System.out.println("remainder 1 case 9");				//left here for testing purposes
				}
				
				else {
					//3 groups of 3 with remaining names in groups of 4
					groupsOf3 = 3;
					groupsOf4 = (list.size() - (groupsOf3 * 3)) / 4;
					totalGroups = groupsOf3 + groupsOf4;
					Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
					textArea.setText(Results);
					//System.out.println("remainder 1");						//left here for testing purposes
				}
			}//else if end
			
			else if((list.size() % 4) == 2 && list.size() > 5) {
				if(list.size() % 3 == 0 && list.size() == 6) {
					//2 groups of 3
					groupsOf3 = 2;
					groupsOf4 = 0;
					totalGroups = groupsOf3;
					Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
					textArea.setText(Results);
					//System.out.println("remainder 2 case 6");				//left here for testing purposes
				}
				
				else {
					//2 groups of 3 with remaining names in groups of 4
					groupsOf3 = 2;
					groupsOf4 = (list.size() - (groupsOf3 * 3)) / 4;
					totalGroups = groupsOf3 + groupsOf4;
					Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
					textArea.setText(Results);
					//System.out.println("remainder 2");						//left here for testing purposes
				}
			}//else if end
			
			else if((list.size() % 4) == 3 && list.size() > 5) {
				//1 group of 3 with the remaining names in groups of 4
				groupsOf3 = 1;
				groupsOf4 = (list.size() - (groupsOf3 * 3)) / 4;
				totalGroups = groupsOf3 + groupsOf4;
				Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
				textArea.setText(Results);
				//System.out.println("remainder 3");							//left here for testing purposes
			}//else if end
			
			else {
				//this section is for groupings divisible by 4
				groupsOf3 = 0;
				groupsOf4 = (list.size() / 4);
				totalGroups = groupsOf4;
				Results = Results.concat(String.valueOf(groupsOf3) + " groups of 3\n" + String.valueOf(groupsOf4) + " groups of 4");
				textArea.setText(Results);
				//System.out.println("divisible by 4");						//left here for testing purposes
			}
			
//			String[][] matrixClone = GroupOrganize(list, totalGroups, groupsOf4);
			matrixCloneAr.add(GroupOrganize(list, totalGroups, groupsOf4));////////////////////////////////////////

			for(int i = 0; i < totalGroups; i++) {
				for(int j = 0; j < 4; j++) {
//			for(Object i : matrixCloneAr) {
					String[][] array = (String[][])matrixCloneAr.get(0);
					System.out.print(array[i][j]);
					if(j == 3) {
						System.out.print(",\n");
					}
//			}
				}
			}
			totalGroupsAr[0] = totalGroups;
			people4Ar[0] = groupsOf4;
			people3Ar[0] = groupsOf3;
			
		//block from Show groupings button		
			Results = textArea.getText() + "\n";

			String reOrder = "";
			String blank = "_";			
			String matrix[][] = new String[totalGroups][4];
			Integer t = 0;
			
			
				for(int i = 0; i < totalGroups; i++) {

					if(groupsOf4 != 0) {
						
						for(int j = 0; j < 4; j++) { //add names
						matrix[i][j] = (String) ((Player) list.get(t)).getName();
						
						
						Results = Results.concat(matrix[i][j] + " ");
						t++;
						}//for loop j end
						groupsOf4--;
					}//if numOf4Groups end
					
					else { //for numOf3Groups
						
						for(int j = 0; j < 4; j++) {
							if(j == 3) {
								matrix[i][j] = blank;
								Results = Results.concat(matrix[i][j] + " ");
							}//if end
							
							else {
							matrix[i][j] = (String) ((Player) list.get(t)).getName();
							
							
							Results = Results.concat(matrix[i][j] + " ");
							t++;
							}//else end
						}//for loop j end
					}//else numOf3Groups end
					Results = Results.concat("\n");
				}//for loop end
				
				
				
			//adding names to the enter wins tab only if the amount of names are divisible by 4
			//right now this is using the matrix to add to the combo boxes but in the future it
			//would be beneficial to use the player object instead of the string text from the matrix
			if(list.size() % 4 == 0) {
				
					for(int i = 0; i < 4; i++) {
						if (i == 0) {
							for(int j = 0; j < 4; j++) {
								cBox1Place1.getItems().add(matrix[i][j]);
							}
						}
						else if(i == 1) {
							for(int j = 0; j < 4; j++) {
								cBox2Place1.getItems().add(matrix[i][j]);
							}
						}
							
						else if(i == 2) {
							for(int j = 0; j < 4; j++) {
								cBox3Place1.getItems().add(matrix[i][j]);
							}
						}
						else {
							for(int j = 0; j < 4; j++) {
								cBox4Place1.getItems().add(matrix[i][j]);
							}
						}
					}
					cBox1Place2.setItems(cBox1Place1.getItems());
					cBox1Place3.setItems(cBox1Place1.getItems());
					cBox1Place4.setItems(cBox1Place1.getItems());
					
					cBox2Place2.setItems(cBox2Place1.getItems());
					cBox2Place3.setItems(cBox2Place1.getItems());
					cBox2Place4.setItems(cBox2Place1.getItems());
					
					cBox3Place2.setItems(cBox3Place1.getItems());
					cBox3Place3.setItems(cBox3Place1.getItems());
					cBox3Place4.setItems(cBox3Place1.getItems());
					
					cBox4Place2.setItems(cBox4Place1.getItems());
					cBox4Place3.setItems(cBox4Place1.getItems());
					cBox4Place4.setItems(cBox4Place1.getItems());
			}
//				else if (list.size() / 4 == 2) {
//					for(int i = 0; i < 4; i++) {
//						cBox1Place1.getItems().add(((Player) list.get(i)).getName());
//					}
//				}
				
				
				
				
				textArea.setText(Results);
			
			setup.getTabPane().getTabs().remove(setup);
		});//finalize button end
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	//Show Names button
		allNames.setOnAction(e -> {
			String Results = "";
			String names = "";
			int wins;
			
			for(int i = 0; i < list.size(); i++) {

			names = (String) ((Player) list.get(i)).getName();
			wins = (Integer) ((Player) list.get(i)).getWins();

			Results = Results.concat(names + " - " + wins + "\n");

			}//for loop end
			
			try {
			((Player) list.get(0)).getName();
			}//try end
			catch (Exception k) {
				Results = "Please enter a name into the text field";
			}//catch end
			finally {
				textWins.setText(Results);
			}//finally end
			
			
		});//allNames.setOnAction(e -> { end
		
		
		
	//Calculate groups button
		addARound.setOnAction(e -> {
			Integer addingRound = Integer.parseInt(roundsLeft.getText());
			addingRound++;
			roundsLeft.setText(String.valueOf(addingRound));
		});//Calculate groups button action end
		
		
		
		
		
		
		
		
		
		
		
		stopWatch.setOnAction(e -> {
			
		if(Integer.valueOf(roundsLeft.getText()) == 0) {
			textWins.setText("There are no more rounds to play,\n"
					+ "click the Names and Wins button\nto award booster packs");
		}
		else {
		roundsLeft.setText(Integer.toString(Integer.valueOf(roundsLeft.getText()) - 1));

		Integer start = Integer.parseInt(timeLeft.getText());
		
		for(Integer i = start; i > -1; i--) {

			String starting = i.toString();

			timeLeft.setText(String.valueOf(i));
			try {	
				timeLeft.setText(String.valueOf(i));
				Thread.sleep(1000);
				//1 minute = 60,000 miliseconds
				//1 second = 1000 miliseconds
				timeLeft.setText(starting);
				
				tabPane.getSelectionModel().selectNext();
				
			}
			
			catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			
		}//for loop i end
		}

//			System.out.print(start);
		});
		
		
		
		
		
		
		enterPlaces.setOnAction(e -> {
			
			
			tabPane.getSelectionModel().selectPrevious();
			
		});
		
		
		
		
		
		
		
	//Rerandomize button action
		//if btnRandoPress[0] == 4 then btnRandoPress[0] = -1
		//when btnRandoPress[0] is reset then a new matrix array
		//is initialized
		//try to in the future add a way to check if a player has
		//been played before by that player that played a match
		//with them. when a new random group is generated it will
		//look through the players and assign them numbers of times
		//played. could make a group of objects called groups that
		//would do the same thing and only be limited by the groups
		//playing. if I went the player route then they would be
		//objects as well.
		
//dont forget to work on the else statement because it is commented out currently
		
		reRandomize.setOnAction(e -> {////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			String[][] array = (String[][])matrixCloneAr.get(0);
			
			String[][] arrayClone = new String[totalGroupsAr[0]][4];
			
			String results = textArea.getText() + "\n";
			
			if(btnRandoPress[0] == totalGroupsAr[0] - 1) {
				int g4 = 0;
				int g3 = 0;
				int r = 0;
				int c = 0;
				String miss = array[totalGroupsAr[0] - 1][3];
				
				btnRandoPress[0] = 0;
				

				for(int i = 0; i < totalGroupsAr[0]; i++) {
					for(int j = 0; j < 4; j++) {
						if(g4 < people4Ar[0]) {
							if(r == totalGroupsAr[0]) {
								c++;
								r = 0;
								arrayClone[i][j] = array[r][c];
								results = results.concat(arrayClone[i][j] + " ");
								r++;
							}
							else {
							arrayClone[i][j] = array[r][c];
							results = results.concat(arrayClone[i][j] + " ");
							r++;
							}
						}
						
						else {
//							System.out.println(r + " " + c + " " +  i + " " +  j);
//							if(array[i][j].equals("_") == true) {
//								miss = arrayClone[i][j];
//							}
													
//							else {
								if(r == totalGroupsAr[0]) {
									c++;
									r = 0;
									arrayClone[i][j] = array[r][c];
									results = results.concat(arrayClone[i][j] + " ");
									r++;
								}//if end
								else {
									arrayClone[i][j] = array[r][c];
									results = results.concat(arrayClone[i][j] + " ");
									r++;
								}//else end

							
//						}//else end
							
						}//else end checks for groups of 2
						
						System.out.print(arrayClone[i][j]);
						if(j == 3) {
							results = results.concat("\n");
							System.out.print(",\n");
						}

					}//for loop j end
					g4++;
				}//for loop i end
				
				
		//was working here to solve why the array wont print the "_" at the end of that array - unfinished
//				for(int i = 0; i < totalGroupsAr[0]; i++) {
//					for(int j = 0; j < 4; j++) {
//						
//						if(array[i][j].equals("_") == false && people3Ar[0] > 0 && j == 3) {
//							miss = arrayClone[i][j];
//							
//							for(int k = 0; k < 4; k++) {
//								if(arrayClone[i][k].equals("_") == true && j != 3) {
//									arrayClone[i][k] = miss;
//									if(arrayClone[i][3].equals("_") == false && miss.equals(arrayClone[i][3]) == true) {
//										arrayClone[i][3] = "_";
//									}//if end
//								}//if end
//							}//for loop k end
//						}//if end
//					}//for loop j end
//				}//for loop i end
				
				matrixCloneAr.set(0, arrayClone);

				
	//need to work here in the if statement. if button press equals total groups then redo groups with the first name and down
				//if groups of 4			people4Ar is the groups of 4 array check to make sure that these arrays are in the right spot
				//if groups of 3			people3Ar is the groups of 3 array
			}
			else {//big else start
			System.out.println("\n");
			
			for(int i = 0; i < totalGroupsAr[0]; i++) {
				for(int j = 0; j < 4; j++) {
					arrayClone[i][j] = array[i][j];
				}
			}
			
			int k = 0;
				
			btnRandoPress[0] = btnRandoPress[0] + 1;

			
			for(int i = 0; i < totalGroupsAr[0]; i++) {

				k = i;

				for(int j = 0; j < 4; j++) {
					
					try {
						
							if(k == totalGroupsAr[0]) {
								k = 0;
								arrayClone[i][j] = array[k][j];
							}
							
							else {
								arrayClone[i][j] = array[k][j];
							}
							k++;

						
						System.out.print(arrayClone[i][j]);
						results = results.concat(arrayClone[i][j] + " ");
						
						if(j == 3) {
							results = results.concat("\n");

							System.out.print(",\n");
						}
						
					}//try end
					
					catch(Exception y){
						System.out.print("Something went wrong");	
					}//catch end
					finally {
					}
					
				}//for loop j end
			}//for loop i end
		

						
			matrixCloneAr.set(0, arrayClone);
			
			System.out.println(btnRandoPress[0]);		//left in for testing purposes

			}//big else end
			textArea.setText(results);

			
		});//Rerandomize button action end
		
		
		
	//Unfinished help button
	//try to save this until the end of the program completion
	//so that I only need to write the text once
	//This is placeholder text that is likely not going to change in final version
		help.setOnAction(e -> {
			textWins.setText("How to use this Tournament Calculator\n\n"
							+ "Go to the setup tab and enter names\n"
							+ "Once the names are entered into the\n"
							+ "system then you can see the names\n"
							+ "that were entered and the total num-\n"
							+ "-ber of names. Select the desired\n"
							+ "number of rounds and click finalize\n"
							+ "-Note, when the finalize button is\n"
							+ "clicked the setup tab will not be \n"
							+ "accessible.\n"
							+ "The players will be matched up in \n"
							+ "rounds of play. The left text box \n"
							+ "will show the player groupings, and\n"
							+ "the right text box will show the wins\n"
							+ "and this help text. Rounds left are\n"
							+ "displayed in the small text box under\n"
							+ "the left text box, and the timer is \n"
							+ "under the right text box(Seconds). \n"
							+ "-Note, when the start button is pres-\n"
							+ "-sed then the Rounds left will tick\n"
							+ "down 1 and continue to do so until it\n"
							+ "reaches 0.\n"
							+ "The button called Re-Randomize re- \n"
							+ "-organizes the players into new groups\n"
							+ "displayed in the left text box and the \n"
							+ "Names & Wins button will display all \n"
							+ "names and the wins that they have \n"
							+ "acquired through the tournament play\n"
							+ "The Help button displays this text\n"
							+ "here. In the ");
			
		});//help button action end
		
		
		
		
		setupNames.getChildren().addAll(enterNames, textField);
		setupSysNames.getChildren().addAll(namesIn, nameInSy);
		setupNTotal.getChildren().addAll(namesEntered, nameTotal);
		setupRounds.getChildren().addAll(enterRounds, roundSpin, finalize);

		primaryStage.setTitle("Tourney Command");
		primaryStage.setScene(scene);
		primaryStage.show();

	}//start method end
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//this is where I was working last
	//method creation below
	//the old GroupCalculation method was old and outdated
	
//was in the process of moving computations over to methods here
	public String[][] GroupOrganize(ArrayList list, int totalGroups, int groupsOf4){
		

		String reOrder = "";
		String blank = "_";			
		String matrix[][] = new String[totalGroups][4];
		Integer t = 0;
		
		for(int i = 0; i < totalGroups; i++) {

			if(groupsOf4 != 0) {
				
				for(int j = 0; j < 4; j++) { //add names
				matrix[i][j] = (String) ((Player) list.get(t)).getName();
				
				t++;
				
				}//for loop j end
				
				groupsOf4--;
				
			}//if numOf4Groups end
			
			else { //for numOf3Groups
				
				for(int j = 0; j < 4; j++) {
					if(j == 3) {
						matrix[i][j] = blank;
					}//if end
					
					else {
					matrix[i][j] = (String) ((Player) list.get(t)).getName();
					
					t++;
					}//else end
				}//for loop j end
			}//else numOf3Groups end
		}//for loop end
		
		return matrix;
		
		
	}//GroupCalculation method end
	
//	public String[][] GroupArrayMethod(){
//		
//	}
	
	
}//Class Tourney_Command end

