package tourneyCommand;

public class Player{
	String name;
	Integer wins = 0;
	
	public String getName() {
		return name;
	}
	
	public void setName(String newName) {
		name = newName;
	}
	
	public Integer getWins() {
		return wins;
	}
	
	public void addWin() {
		wins++;
	}

	
}
